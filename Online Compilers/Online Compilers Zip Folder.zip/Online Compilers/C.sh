#!/usr/bin/bash -l

echo "Loading the C# online compiler site..."
setsid firefox https://www.onlinegdb.com/online_c_compiler &
sleep 1
