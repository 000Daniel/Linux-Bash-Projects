----Information----
This script opens a coding site on Firefox(only), depending on what language you chose. 
These scripts were designed to work on Ubuntu based distros with Firefox installed.
I developed these scripts on 'Zorin OS', and haven't tested them on any other OS.

----Installation----
1. Extract the .zip contents into the same folder(Example, both files on Desktop)
2. Open the terminal and 'cd' to the files' directory(Example, cd Desktop/)
3. Write 'chmod 755 Online\ Compiler' (you might need to write Sudo)
4. Write 'cd Online\ Compilers/'
5. Run the next commands:
chmod 755 C.sh
chmod 755 C++.sh
chmod 755 CS.sh
chmod 755 Python.sh
chmod 755 Java.sh

Note: alternative to '755' you can also use '+x' however it didn't work for me.
6. And there you go! you can now start 'Online Compiler.sh'! (Execute in a terminal)

You can also start the script from a terminal:
----Starting from a Terminal----
1. 'cd' to the files' directory(Example, cd Desktop/)
2. Write: 'bash Online\ Compiler.sh'

#Release date: 12.09.2021
