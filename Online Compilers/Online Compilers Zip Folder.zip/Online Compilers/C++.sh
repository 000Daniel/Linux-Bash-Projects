#!/usr/bin/bash

echo "Loading the C# online compiler site..."
setsid firefox https://www.onlinegdb.com/online_c++_compiler &
sleep 1
