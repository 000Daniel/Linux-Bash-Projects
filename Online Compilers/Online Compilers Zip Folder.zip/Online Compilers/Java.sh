#!/usr/bin/bash

echo "Loading the C# online compiler site..."
setsid firefox https://www.onlinegdb.com/online_java_compiler &
sleep 1
