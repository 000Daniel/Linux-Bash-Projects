#!/usr/bin/bash

echo "Loading the C# online compiler site..."
setsid firefox https://www.onlinegdb.com/online_csharp_compiler &
sleep 1
